# -*- coding: utf-8 -*-
"""解析 jhx3d.com 活动列表页 SSR payload，输出几何芯比赛精简记录。

用法:
    python parse_jhx.py [输入html] [输出json]
默认: jhx_list.html -> tmp_joykings.json（当前工作目录）
输出条目的 url 域名统一为 https://www.jhx3d.com/activitys/detail/{id}
"""
import re, json, os, sys

in_html = sys.argv[1] if len(sys.argv) > 1 else "jhx_list.html"
out_json = sys.argv[2] if len(sys.argv) > 2 else "tmp_joykings.json"

s = open(in_html, encoding="utf-8", errors="ignore").read()

# 找到含 records 的 push 调用（可能有多个 push，取含 competitionId 的）
m = None
for pm in re.finditer(r'self\.__next_f\.push\(\[1,"(.*?)"\]\)', s, re.S):
    if '"competitionId"' in pm.group(1) or 'records' in pm.group(1):
        m = pm
        break
if not m:
    raise SystemExit("no payload found")

raw = m.group(1)
# 这是 JS 字符串字面量内容：反斜杠转义。逐字符还原最外层转义
out_chars = []
i = 0
while i < len(raw):
    c = raw[i]
    if c == "\\" and i + 1 < len(raw):
        n = raw[i+1]
        if n == '"':
            out_chars.append('"'); i += 2; continue
        elif n == "\\":
            out_chars.append("\\"); i += 2; continue
        elif n == "n":
            out_chars.append("\n"); i += 2; continue
        elif n == "t":
            out_chars.append("\t"); i += 2; continue
        elif n == "/":
            out_chars.append("/"); i += 2; continue
        elif n == "u":
            out_chars.append(raw[i:i+6]); i += 6; continue  # 保留 unicode 转义给 json 解码
        else:
            out_chars.append(c); i += 1; continue
    out_chars.append(c); i += 1
inner = "".join(out_chars)

# inner 形如: 1b:["$","$L31",null,{...records...}] —— 找 records 数组
idx = inner.find('"records":[')
if idx < 0:
    raise SystemExit("records not found")
start = inner.find("[", idx)
depth = 0
end = None
for i in range(start, len(inner)):
    if inner[i] == "[":
        depth += 1
    elif inner[i] == "]":
        depth -= 1
        if depth == 0:
            end = i + 1
            break
# 内部还可能含 \uXXXX，先转成真正的 unicode 再解析
seg = inner[start:end]
seg = re.sub(r'\\u([0-9a-fA-F]{4})', lambda x: chr(int(x.group(1), 16)), seg)
records = json.loads(seg)
print("records:", len(records))
out = []
for r in records:
    cid = r.get("competitionId")
    out.append({
        "competitionId": cid,
        "title": " ".join((r.get("title") or "").replace("\\n", " ").replace("\n", " ").split()),
        "miniStatus": r.get("miniStatus"),
        "regStartTime": r.get("regStartTime"),
        "regEndTime": r.get("regEndTime"),
        "resultPublishTime": r.get("resultPublishTime"),
        "url": "https://www.jhx3d.com/activitys/detail/{}".format(cid),
    })
for o in sorted(out, key=lambda x: x["competitionId"]):
    print(o["competitionId"], o["miniStatus"], "|", (o["regStartTime"] or "")[:10], "~", (o["regEndTime"] or "")[:10], "|", o["title"][:45])
json.dump(out, open(out_json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("saved", out_json)
