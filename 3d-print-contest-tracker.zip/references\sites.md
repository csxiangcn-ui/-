# 3D 打印模型平台比赛抓取参考

## 平台列表

### 1. creality-cn (创想云国内)
- **比赛列表页**: `https://m.crealitycloud.cn/contest` (手机版，服务端渲染)
- **抓取方法**: WebFetch 抓取 m.crealitycloud.cn/contest，解析出比赛卡片
- **注意**: 桌面版 crealitycloud.cn 是 JS 客户端渲染，WebFetch 抓不到内容，必须用手机版 m.crealitycloud.cn
- **比赛详情 URL 格式**: `https://www.crealitycloud.cn/contest/{id}`
- **颜色**: `#FF6B35`

### 2. creality-intl (创想云国际)
- **比赛列表页**: `https://www.crealitycloud.com/zh/contest`
- **抓取方法**: WebFetch 直接抓取
- **颜色**: `#FF8C42`

### 3. makeronline (纵维立方)
- **比赛列表页**: `https://www.makeronline.com/zh/contestList`
- **抓取方法**: WebFetch 直接抓取
- **颜色**: `#4ECDC4`

### 4. makerworld-cn (拓竹国内)
- **比赛列表页**: `https://makerworld.com.cn/zh/contests`
- **抓取方法**: WebFetch 直接抓取
- **颜色**: `#FF6F61`

### 5. makerworld-intl (拓竹国际)
- **比赛列表页**: `https://makerworld.com/zh/contests`
- **抓取方法**: WebFetch 直接抓取
- **颜色**: `#E55B5B`

### 6. jlc (嘉立创)
- **比赛列表页**: `https://model.jlc-3dp.cn/race`
- **抓取方法**: WebFetch 直接抓取
- **颜色**: `#5B9BD5`

### 7. makeroad (三绿)
- **比赛列表页**: `https://www.makeroad.com/zh/contests`
- **抓取方法**: WebFetch 直接抓取
- **颜色**: `#52C41A`

### 8. snapmaker (快造)
- **比赛列表页1**: `https://models.snapmaker.com/contest/1`
- **比赛列表页2**: `https://models.snapmaker.com/contest/2`
- **抓取方法**: 该平台比赛分布在多个独立页面，需分别抓取 contest/1 和 contest/2，还可能更多
- **颜色**: `#722ED1`

### 9. nexprint (爱乐酷)
- **比赛列表页**: `https://www.nexprint.com/zh/contests`
- **抓取方法**: 该平台无独立比赛详情页，所有比赛统一指向 `https://www.nexprint.com/zh/contests`
- **颜色**: `#EB2F96`

## 数据结构

每个比赛的数据格式（contests.json 中每项）:

```json
{
  "site": "creality-cn",
  "name": "比赛名称",
  "desc": "比赛主题/描述",
  "start": "2026-07-01",
  "end": "2026-07-31",
  "url": "比赛详情页URL",
  "status": "ongoing"
}
```

- `status` 字段可选，留空或不写时由 generate_page.py 根据日期自动判断
- 手动指定 `"judging"` 或 `"ended"` 会覆盖自动判断
- 所有日期格式为 `YYYY-MM-DD`

## 状态自动判断规则

```
today < start   → upcoming (待开始)
start ≤ today ≤ end → ongoing (进行中)
today > end     → ended (已结束)
标记 judging    → 评审中（不自动改变）
```

## 截止日期修正规则（重要）

部分平台的截止时间标注为 `00:00:00`（即某日零时零分），这意味着**前一天 24:00 就已关闭提交**。这种情况下 `end` 日期必须往前调一天。

**受影响平台：**
- **makeronline (纵维立方)**: 所有比赛截止时间均为 `YYYY-MM-DD 00:00:00`，end 应写标注日 -1

**示例：**
- 页面写 "2026-07-26 00:00:00 截止，7/26 评审" → end 写 `2026-07-25`

**不受影响的平台**（标注日当天仍可参赛）：
- creality-cn、creality-intl、makerworld-cn、makerworld-intl、jlc、makeroad、snapmaker、nexprint

抓取时务必检查每个平台截止时间的**精确时分**描述，有 `00:00` 或 `0时` 的就 -1 天。不要对未确认的平台擅自修正。
