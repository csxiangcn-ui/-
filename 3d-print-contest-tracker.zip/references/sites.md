# 3D 打印模型平台比赛抓取参考

## 平台列表

### 1. creality-cn (创想云国内)
- **比赛列表页**: `https://m.crealitycloud.cn/contest` (手机版)
- **抓取方法**: **必须走 API**（WebFetch 手机版只能抓到置顶 1 场，会漏掉大量比赛）：
  `POST https://api.crealitycloud.cn/api/cxy/v2/allActivity/list`，body `{"page":1,"pageSize":100,"lang":"zh"}`，header 加 `Origin: https://m.crealitycloud.cn`
- **返回**: `result.list`，字段 `name/desc/startTime/endTime`(秒级时间戳，`datetime.fromtimestamp` 转日期) `/linkUrl`(JSON 字符串，内含 `url`) `/activityType/acStatus`
- **只取 `activityType=9`（模型设计比赛）**，其余 type 8/6/2/3 是帖子/邀请/抽奖活动，忽略
- **acStatus 映射**: `1=待开始(预告/upcoming)`、`2=进行中(ongoing)`、`6=评审中(judging)`、`3=已结束(ended)`
- **详情 URL**: 取 `linkUrl` 解析后的 `url`（http 改 https）
- **注意**: 桌面版 `www.crealitycloud.cn` 是 JS 渲染抓不到；手机版 `m.crealitycloud.cn/contest` 也只返回置顶，务必用 API
- **颜色**: `#FF6B35`

### 2. creality-intl (创想云国际)
- **比赛列表页**: `https://www.crealitycloud.com/zh/contest`
- **抓取方法**: WebFetch 直接抓取
- **颜色**: `#FF8C42`

### 3. makeronline (纵维立方)
- **比赛列表页**: `https://www.makeronline.com/zh/contestList`
- **抓取方法**: WebFetch 直接抓取
- **颜色**: `#4ECDC4`

### 4. makerworld-cn (拓竹国内)
- **比赛列表页**: `https://makerworld.com.cn/zh/contests`
- **抓取方法**: WebFetch 直接抓取
- **颜色**: `#FF6F61`

### 5. makerworld-intl (拓竹国际)
- **比赛列表页**: `https://makerworld.com/zh/contests`
- **抓取方法**: WebFetch 直接抓取
- **颜色**: `#E55B5B`

### 6. jlc (嘉立创)
- **比赛列表页**: `https://model.jlc-3dp.cn/race`
- **抓取方法**: WebFetch 直接抓取
- **颜色**: `#5B9BD5`

### 7. makeroad (三绿)
- **比赛列表页**: `https://www.makeroad.com/zh/contests`（JS 渲染，curl 直读 HTML 为 0 字节，WebFetch 结果不稳定）
- **抓取方法**: **必须用 API** `GET https://www.makeroad.com/api/contest/list`，header 带 `Referer: https://www.makeroad.com/zh/contests`。返回 `data.list`，字段：name/gameTimeStart/gameTimeEnd(秒级时间戳)/status/url 用 `https://www.makeroad.com/contests/{id}`
- **status 映射**: `3`=进行中、`4`=评审中(judging，投稿期截止后未出结果)、`5`=已结束(ended)。**只有 5 才算 ended**，4 必须标 judging 不能删。曾因把 status=4 的评审中比赛当已结束误删（08-24 教训）
- **颜色**: `#52C41A`

### 8. snapmaker (快造)
- **比赛列表页1**: `https://models.snapmaker.com/contest/1`
- **比赛列表页2**: `https://models.snapmaker.com/contest/2`
- **抓取方法**: 该平台比赛分布在多个独立页面，需分别抓取 contest/1 和 contest/2，还可能更多
- **颜色**: `#722ED1`

### 9. nexprint (爱乐酷)
- **比赛列表页**: `https://www.nexprint.com/zh/contests`
- **抓取方法**: 该平台无独立比赛详情页，所有比赛统一指向 `https://www.nexprint.com/zh/contests`
- **颜色**: `#EB2F96`

### 10. joykings3d (几何芯)
- **⚠️ 2026-09-05 起站点迁移**：原域名 `www.joykings3d.com` 只剩英文海外站（详情页/旧 API 全 404），中文比赛站迁移至 **`www.jhx3d.com`**
- **比赛列表页**: `https://www.jhx3d.com/activitys/list`
- **抓取方法**: 抓列表页 HTML 后解析 `self.__next_f.push` RSC payload 中的 `records` 数组（Next.js SSR）。用脚本解析（参考项目 `scripts/parse_jhx.py`），不要 WebFetch（payload 会被截断）
- **比赛详情 URL 格式**: `https://www.jhx3d.com/activitys/detail/{id}`
- **颜色**: `#00B8A9`

## 数据结构

每个比赛的数据格式（contests.json 中每项）:

```json
{
  "site": "creality-cn",
  "name": "比赛名称",
  "desc": "比赛主题/描述",
  "start": "2026-07-01",
  "end": "2026-07-31",
  "url": "比赛详情页URL",
  "status": "ongoing"
}
```

- `status` 字段可选，留空或不写时由 generate_page.py 根据日期自动判断
- 手动指定 `"judging"` 或 `"ended"` 会覆盖自动判断
- 所有日期格式为 `YYYY-MM-DD`

## 状态自动判断规则

```
today < start   → upcoming (待开始)
start ≤ today ≤ end → ongoing (进行中)
today > end     → ended (已结束)
标记 judging    → 评审中（不自动改变）
```

## 截止日期修正规则（重要）

部分平台的截止时间标注为 `00:00:00`（即某日零时零分），这意味着**前一天 24:00 就已关闭提交**。这种情况下 `end` 日期必须往前调一天。

**受影响平台：**
- **makeronline (纵维立方)**: 所有比赛截止时间均为 `YYYY-MM-DD 00:00:00`，end 应写标注日 -1

**示例：**
- 页面写 "2026-07-26 00:00:00 截止，7/26 评审" → end 写 `2026-07-25`

**不受影响的平台**（标注日当天仍可参赛）：
- creality-cn、creality-intl、makerworld-cn、makerworld-intl、jlc、makeroad、snapmaker、nexprint、joykings3d

抓取时务必检查每个平台截止时间的**精确时分**描述，有 `00:00` 或 `0时` 的就 -1 天。不要对未确认的平台擅自修正。
