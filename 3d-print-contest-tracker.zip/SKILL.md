---
name: 3d-print-contest-tracker
description: "3D 打印模型平台比赛汇总追踪器。当用户要求创建/生成/更新 3D 打印比赛汇总页面、聚合各平台比赛信息、3D 模型比赛看板、比赛追踪仪表盘，或提到 MakerWorld/创想云/拓竹/纵维立方/嘉立创/三绿/快造/爱乐酷/几何芯等平台比赛时使用此 Skill。"
agent_created: true
---

# 3D Print Contest Tracker

## Overview

聚合 10 个主流 3D 打印模型平台的比赛信息，生成一个纯静态 HTML 看板页面（卡片+列表+日历+时间线+暗色模式+收藏功能），可选部署到 GitHub Pages。

## Workflow

### Step 1: 抓取各平台比赛数据

并行抓取以下 10 个平台（尽可能多地同时 WebFetch）:

| 平台 key | 抓取 URL |
|----------|----------|
| creality-cn | `https://m.crealitycloud.cn/contest` |
| creality-intl | `https://www.crealitycloud.com/zh/contest` |
| makeronline | `https://www.makeronline.com/zh/contestList` |
| makerworld-cn | `https://makerworld.com.cn/zh/contests` |
| makerworld-intl | `https://makerworld.com/zh/contests` |
| jlc | `https://model.jlc-3dp.cn/race` |
| makeroad | `https://www.makeroad.com/zh/contests` |
| snapmaker | `https://models.snapmaker.com/contest/1` 和 `https://models.snapmaker.com/contest/2` |
| nexprint | `https://www.nexprint.com/zh/contests` |
| joykings3d | 抓 `https://www.jhx3d.com/activitys/list` 解析 SSR（见下方 API 说明，2026-09-05 起站点迁移） |

**关键注意事项**:
- 创想云国内 **必须用 API 抓完整列表**（WebFetch 手机版只能抓到置顶 1 场）：
  `POST https://api.crealitycloud.cn/api/cxy/v2/allActivity/list`，body `{"page":1,"pageSize":100,"lang":"zh"}`，header 加 `Origin: https://m.crealitycloud.cn`。
  返回 `result.list`，字段 `name/desc/startTime/endTime`(秒级时间戳，`datetime.fromtimestamp` 转日期) `/linkUrl`(JSON 字符串，内含 `url`) `/activityType/acStatus`。**时间戳是本地时区整点：start=00:00:00、end=23:59:59，直接用 `datetime.fromtimestamp` 转日期即可，不要额外 -1**（历史数据曾因网页 UTC 显示导致 start 整体少 1 天）。
  **只取 `activityType=9`（模型设计比赛）**，其余 type 8/6/2/3 是帖子/邀请/抽奖活动需忽略。`acStatus` 映射：**1=待开始(预告/upcoming)**、2=进行中、6=评审中、3=已结束。详情 URL 取 `linkUrl` 解析后的 `url`（http 改 https）。桌面版 `www.crealitycloud.cn` 是 JS 渲染抓不到。
- 快造 (snapmaker) 需要 **分别抓取** contest/1 和 contest/2 两个页面
- 爱乐酷 (nexprint) **无独立比赛页**，所有比赛统一指向 `https://www.nexprint.com/zh/contests`
- 几何芯 (joykings3d) **⚠️ 2026-09-05 起站点迁移，旧方法已失效**：原域名 `www.joykings3d.com` 现只剩英文海外站，旧 API `POST /api/web/competition/page` 与详情页 `/activitys/detail/{id}` 全部返回 404/HTML。中文比赛站迁移到 **`www.jhx3d.com`**：抓 `https://www.jhx3d.com/activitys/list`（Next.js SSR，比赛数据嵌在页面 `self.__next_f.push` 的 RSC payload 的 `"records"` 数组中），详情 URL 一律用 `https://www.jhx3d.com/activitys/detail/{competitionId}`。推荐用脚本 `scripts/parse_jhx.py` 从 HTML 提取 records（先 curl 落地页面再解析，不要 WebFetch——RSC payload 会被截断）。记录字段：`regStartTime`→start、**`regEndTime`→end（报名提交截止，23:59:59 取日期部分）**、`resultPublishTime` 是公布结果时间**不要用作 end**。`miniStatus` 映射：in_progress=ongoing、not_started/upcoming=upcoming、ended/finished=ended（跳过）、review/reviewing=judging。注意 `title` 字段含**字面 `\n` 字符**（反斜杠+n，非真实换行），须先 `replace("\\n"," ")` 归一化空白再匹配。

从每个平台抓取的页面中提取:
- 比赛名称 (name)
- 主题/描述 (desc)
- 开始日期 (start, 格式 YYYY-MM-DD)
- 截止日期 (end, 格式 YYYY-MM-DD)
- 比赛详情 URL (url)

**截止日期修正规则**:
- makeronline (纵维立方): 该平台截止时间均为 `YYYY-MM-DD 00:00:00`，实际最后参赛日是前一天，end 必须 -1 天。
- joykings3d (几何芯): **end 一律取 `regEndTime` 字段的日期部分（报名提交阶段截止，23:59:59 直接截取 YYYY-MM-DD）**，绝不能用活动整体结束日或 `resultPublishTime`（公布结果时间通常晚 1~2 周，仅用于评审/投票/公布）。站点已迁移见上文说明。
- 其他平台不擅自修正。详见 `references/sites.md`。

**已结束比赛不显示**: generate_page.py 生成时自动过滤 status=ended 的比赛。页面只显示进行中/待开始/评审中。

**git 提交规范（重要）**: 推送到 GitHub 时**禁止 `git add -A`**——仓库根目录不能出现 `.github/workflows/*.yml`（PAT 无 workflow scope 会导致 push 被拒）。只精确 add 数据文件：
```
cd <项目目录> && git add contests.json 3d-contests.html && git commit -m "Daily update" && git push
```
若发现本地存在 `.github/` 目录（历史遗留的 GitHub Actions 配置，实际部署走 WorkBuddy 定时任务），直接删除该目录，不要提交。

**抓取效率优化（省积分，务必遵守）**:
- WebFetch 的 prompt 明确要求**只返回紧凑 JSON 数组**（每项仅 name/start/end/status/url 5 个字段），并写明「不要输出描述文字、不要罗列参赛模型名称」。desc 只在有变化或新增时单独补，别让页面返回整页几十个模型的名称与链接（这是最大的积分消耗源）。
- **一次拿全，不要重复抓**：某平台新比赛拿不到详情 URL 时，先用主站 URL 兜底，不要反复 fetch 同一列表页 + 再 WebSearch。
- 创想云 API **一次 fromtimestamp 即可**，不要为核对时区重复请求。
- diff 匹配用**两轮扫描**：第一轮按 name、第二轮按 url（同 URL 平台如 nexprint 多条共用主站 URL 时第二轮易错配，必须保证每个新条目只消费一次）。
- **URL 落位规则**：仅 name 精确匹配成功才允许 url 被新值覆盖（预告转正式、域名迁移需要）；url 兜底匹配不覆盖 url，防同 URL 平台串改。

### Step 2: 增量更新 contests.json（极其重要）

**核心原则: 永远增量更新，绝不全量重写。**

原因: WebFetch 结果经常不完整 — 部分平台 JS 渲染只展示首屏、ended 比赛在单独 tab 中、个别比赛不在首页列表但仍在线。全量重写会导致已有数据丢失。

#### 2a: 先读旧数据

WebFetch 之前 **必须先** `Read` 现有 `contests.json`，解析为内存对象。

#### 2b: 逐平台 diff（不可跳过）

对每个平台，将 fetch 结果与旧数据按 **比赛名称（name 字段）** 进行匹配:

| 匹配结果 | 操作 |
|----------|------|
| 名称完全一致 | 比较 start/end 日期和 status 标签；**仅当不同时才更新字段** |
| fetch 中有，旧数据无 | **追加**新比赛条目 |
| 旧数据有，fetch 中无 | **不自动删除**。如果是 ended 状态直接保留；如果是 ongoing/upcoming，逐一用 WebFetch 访问其详情页确认是否仍在线 |

#### 2c: 写入原则

- 用 `Edit` 工具做**字段级别的修改**，避免 `Write` 整段覆盖
- 新增比赛: 在对应 platform 分组的末尾插入
- 更改字段: 用 `old_string` 精确匹配旧值，`new_string` 设新值
- 删除比赛: 只在确认页面确实不展示且已结束的前提下删除

#### 数据格式

```json
{
  "site": "平台key",
  "name": "比赛名称",
  "desc": "主题描述",
  "start": "YYYY-MM-DD",
  "end": "YYYY-MM-DD",
  "url": "比赛详情URL",
  "status": "ongoing"
}
```

- `status` 可省略，由页面 JS 根据日期自动判断
- 确实处于评审期的比赛标记 `"status": "judging"`
- 各平台颜色映射见 `assets/template.html` 中 SITES 对象的 `color` 字段

### Step 3: 生成 HTML 页面

1. 读取 `assets/template.html`
2. 构建 SITES 对象（含平台名称、主页 URL、颜色），reference 见 `references/sites.md`
3. 替换 template.html 中的四个占位符:

| 占位符 | 替换内容 |
|--------|---------|
| `/*__SITES__*/` | SITES 对象的 JSON 字符串 |
| `/*__CONTESTS__*/` | 比赛数据数组的 JSON 字符串 |
| `/*__LABEL__*/` | `{"ongoing":"进行中","upcoming":"待开始","judging":"评审中","ended":"已结束"}` |
| `/*__UPDATE__*/` | 当前时间字符串 `YYYY-MM-DD HH:MM` |

4. 写入输出文件 `3d-contests.html`

状态自动判断逻辑（页面 JS 中已内置，`auto_status` 函数）:
- today < start → upcoming
- start ≤ today ≤ end → ongoing
- today > end → ended
- 手动标记 judging 不自动覆盖

### Step 4 (可选): 部署到 GitHub Pages

如果用户要求部署:
1. 确认用户有 GitHub 仓库和 Personal Access Token
2. 将生成的 `3d-contests.html` 推送到仓库
3. 在 GitHub 仓库 Settings → Pages 中开启 GitHub Pages
4. 告知用户访问 URL: `https://{username}.github.io/{repo}/3d-contests.html`

### Step 5 (可选): 设置每日自动更新

如果用户要求自动更新:
1. 使用 `automation_update` 工具创建每日定时任务
2. 建议时间: 每天早上 8:00
3. RRULE: `FREQ=DAILY;BYHOUR=8`
4. 任务内容: 执行 Step 1-3，如果配了 GitHub Pages 则自动推送

## 生成页面功能

生成的 HTML 是纯静态单文件，包含:
- 卡片视图 + 列表视图切换
- 按平台/状态筛选
- 关键字搜索
- 日历视图（显示每天截止的比赛，点击可筛选）
- 时间线（未来 7 天截止的比赛）
- 暗色模式（浏览器 localStorage 记忆）
- ⭐ 收藏功能（浏览器 localStorage 记忆）
- 📂 导入 contests.json 离线更新
- 倒计时自动刷新（每分钟）
- 3 天内/7 天内截止紧急提醒横幅

## 平台颜色参考

| 平台 key | 颜色 |
|----------|------|
| creality-cn | #FF6B35 |
| creality-intl | #FF8C42 |
| makeronline | #4ECDC4 |
| makerworld-cn | #FF6F61 |
| makerworld-intl | #E55B5B |
| jlc | #5B9BD5 |
| makeroad | #52C41A |
| snapmaker | #722ED1 |
| nexprint | #EB2F96 |
| joykings3d | #00B8A9 |
